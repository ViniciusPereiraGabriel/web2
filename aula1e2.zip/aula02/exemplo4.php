<!DOCTYPE html>
<head>
    <meta lang="pt-br">
    <meta charset="UTF-8">
    <title>Primeira aula de php
    </title>
</head>
<body>
    <?php
    $nome;
    $idade;
    $salario;

    $nome ="Aline Zenkler";
    $idade = 30;
    $salario = 3500.50;

    echo "<h1>hello<ins>world</ins>!</h1><hr>" .$nome ."<br> sejam bem vindos, sabemos que voce tem" .$idade ." e recebe " .$salario ."por mes";
    

    ?>
</body>
</html>