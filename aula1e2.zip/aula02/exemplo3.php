<!DOCTYPE html>
<head>
    <meta lang="pt-br">
    <meta charset="UTF-8">
    <title>Primeira aula de php
    </title>
</head>
<body>
    <?php
    $Eduardo = 17;
    echo $Eduardo .'<br>';
    $pai = "Luis Antonio Silva";
    echo $pai . '<br>';
    $preco = 2.58;
    echo $preco .'<br>';
    $inteiro = -50;
    echo $inteiro .'<br>';
    $flutuante = 548.687;
    echo $flutuante .'<br>';
    $string_exemplo = 'paralelepipedo';
    echo $string_exemplo .'<br>';



    
   


    ?>
</body>
</html>