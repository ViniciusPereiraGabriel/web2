<!DOCTYPE html>
<head>
    <meta lang="pt-br">
    <meta charset="UTF-8">
    <title>Primeira aula de php
    </title>
</head>
<body>
    <?php
    echo '<p>começando entendimento de php</p>';
    print ('que todos se sintam animados com o php');
    $valor =' vamos ';
    $Valor ='testar ';
    $_valor ='o uso ';
    $_Valor ='de variaveis ';
    echo $valor, $Valor, $_valor, $_Valor ;


    ?>
</body>
</html>
