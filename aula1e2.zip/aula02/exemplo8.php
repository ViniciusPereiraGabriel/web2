<!DOCTYPE html>
<head>
    <meta lang="pt-br">
    <meta charset="UTF-8">
    <title>Primeira aula de php
    </title>
</head>
<body>
    <?php
    echo "datas <br> <hr>";
    echo "<br>" .date("d/m/y");
    echo "<br>" .date("d/m/Y");
    echo "<br>" .date("h:i:s");

    echo "tambem podera usar como variavel";

    $data = date("d/m/y");
    $hora = date("h:i:s");

    echo "A data atual é ".$data. "A hora atual é " .$hora. "em php";



  


   ?>
</body>
</html>