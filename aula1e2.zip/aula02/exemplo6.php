<!DOCTYPE html>
<head>
    <meta lang="pt-br">
    <meta charset="UTF-8">
    <title>Primeira aula de php
    </title>
</head>
<body>
    <?php
   
   $numero1;
   $numero2;
   $numero3;
   
   $numero1 = 30;
   $numero2 = 20;
   $numero3 = 10;

   $media = ($numero1 + $numero2 = $numero3)/3;

   echo "<p>numero1 : $numero1 <br>

   numero2 : $numero2 <br>

   numero3 : $numero3 <br>
   <strong>media: $media</strong></p>";



   ?>
</body>
</html>