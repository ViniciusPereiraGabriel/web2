<!DOCTYPE html>
<head>
    <meta lang="pt-br">
    <meta charset="UTF-8">
    <title>Primeira aula de php
    </title>
</head>
<body>
    <?php
   $soma = 5 + 6.6;
   $subtracao = 10 - 5.5;
   $divisao = 100 / 9;
   $multiplicacao = 5 * 10.6;
   $resto = 20 % 3;
   $exponenciacao = 10 ** 3;
    
   var_dump($soma);
   echo "<br>";

   var_dump($subtracao);
   echo "<br>";

   var_dump($divisao);
   echo "<br>";

   var_dump($multiplicacao);
   echo "<br>";

   var_dump($exponenciacao);
   echo "<br>";

   var_dump($resto);
   echo "<br>";

  

   ?>
</body>
</html>