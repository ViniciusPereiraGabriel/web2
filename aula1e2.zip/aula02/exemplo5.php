<!DOCTYPE html>
<head>
    <meta lang="pt-br">
    <meta charset="UTF-8">
    <title>Primeira aula de php
    </title>
</head>
<body>
    <?php
    $x = 5 + 5;
    echo $x;
    $nome ="Nicholas";
    echo $nome;
   ?>
</body>
</html>