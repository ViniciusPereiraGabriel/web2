<!DOCTYPE html>
<head>
    <meta lang="pt-br">
    <meta charset="UTF-8">
    <title>Primeira aula de php
    </title>
</head>
<body>
    <?php
    echo '<p> saudaçoes turma tarde</p>';


    ?>
    <p><h1>regras para variavel</h1></p>
    <p>nao usar espaço entre palavras</p>
    <p>nao usar acentos nas variaveis</p>
    <p>nao iniciar com numero as variaveis</p>
    <p>nao utilizar caracteres especiais</p>

    <h2>comentarios em php</h2>

    <p>unica linha // ou #</p>
    <p>comentar em varias linhas</p>
    <p>/*comentario */</p>

</body>
</html>