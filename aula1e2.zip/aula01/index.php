<!DOCTYPE html>
<html>
<head>
    <meta lang="pt-br">
    <meta charset="UTF-8">
</head>
<body>
    <?php
    echo "este é um teste de saida";
    
    ?>
</body>
</html>